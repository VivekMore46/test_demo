from django.urls import path
from . import views
urlpatterns=[
    path('',views.index, name='index'),
    path('about/',views.about, name='about'),
    path('contact/',views.contact, name='contact'),
    path('otp/',views.otp,name='otp'),
    path('register/', views.register, name='register'),
    path('forgot_password/',views.forgot_password,name='forgot_password'),
    path('add_blog/', views.add_blog, name='add_blog'),
    path('my_blog/', views.my_blog, name='my_blog'),
    path('view_blog/', views.view_blog, name='view_blog'),
    path('login/', views.login, name='login'),
    path('profile/', views.profile, name='profile'),
    path('edit_blog/', views.edit_blog, name='edit_blog'),
    path('logout/', views.logout, name='logout'),
    path('change_profile/', views.profile, name='change_profile'),
    

    
]